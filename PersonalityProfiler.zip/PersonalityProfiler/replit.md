# MBTI Personality Assessment Application

## Overview

This is a full-stack web application for conducting MBTI (Myers-Briggs Type Indicator) personality assessments. The application provides an interactive questionnaire that evaluates user responses and generates comprehensive personality type reports with detailed insights, strengths, growth areas, and career recommendations.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for development and production builds
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **State Management**: React hooks with TanStack Query for server state
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Session Management**: Connect-pg-simple for PostgreSQL-backed sessions
- **API Design**: RESTful endpoints with JSON responses
- **Error Handling**: Centralized error middleware

### Database Design
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Shared TypeScript schema definitions
- **Tables**: Users and assessments with proper relationships
- **Migrations**: Drizzle Kit for database schema management

## Key Components

### Assessment Engine
- **Question Bank**: Structured personality questions targeting MBTI dimensions
- **Scoring Algorithm**: Calculates MBTI type based on response patterns
- **Result Generation**: Comprehensive personality reports with breakdowns

### Data Models
- **Users**: Basic user authentication and profile management
- **Assessments**: Stores user responses, calculated scores, and personality types
- **Questions**: Structured assessment questions with dimensional mappings

### UI Components
- **QuestionCard**: Interactive question presentation with radio button selections
- **PersonalityBreakdown**: Visual representation of MBTI dimension scores
- **Progress Tracking**: Real-time assessment progress indicators
- **Results Display**: Comprehensive personality type presentations

## Data Flow

1. **Assessment Start**: User begins assessment on home page
2. **Question Presentation**: Questions displayed sequentially with progress tracking
3. **Response Collection**: User answers stored in local state
4. **Score Calculation**: MBTI algorithm processes responses to determine type
5. **Result Storage**: Assessment results saved to database
6. **Report Generation**: Comprehensive personality report displayed to user

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/react-***: UI primitive components
- **drizzle-orm**: Database ORM and query builder
- **zod**: Runtime type validation and schema definition

### Development Tools
- **Vite**: Frontend build tool and development server
- **TypeScript**: Static type checking and enhanced development experience
- **Tailwind CSS**: Utility-first CSS framework
- **ESBuild**: Fast JavaScript bundler for production builds

## Deployment Strategy

### Development Environment
- **Frontend**: Vite development server with hot module replacement
- **Backend**: tsx for TypeScript execution in development
- **Database**: PostgreSQL connection via environment variables
- **Build Process**: Parallel frontend and backend builds

### Production Build
- **Frontend**: Static files built to `dist/public` directory
- **Backend**: Bundled server code to `dist/index.js`
- **Database**: Drizzle migrations applied via `db:push` command
- **Deployment**: Single Node.js process serving both API and static files

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **NODE_ENV**: Environment specification (development/production)
- **Build Scripts**: Separate development and production configurations

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 08, 2025. Initial setup
- July 08, 2025. Added database integration:
  - Created PostgreSQL database connection with Drizzle ORM
  - Implemented DatabaseStorage class replacing MemStorage
  - Added minimalist SVG personality icons for each MBTI type
  - Updated storage to use PostgreSQL for persistent data storage
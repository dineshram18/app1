import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Brain, Heart, AlertTriangle, Briefcase, RotateCcw, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { PersonalityBreakdown } from "@/components/personality-breakdown";
import { PersonalityIcon } from "@/components/personality-icons";
import { personalityTypes } from "@/lib/personality-types";
import type { Assessment } from "@shared/schema";

interface ResultsProps {
  params: { id: string };
}

export default function Results({ params }: ResultsProps) {
  const [, setLocation] = useLocation();
  const assessmentId = parseInt(params.id);

  const { data: assessment, isLoading, error } = useQuery<Assessment>({
    queryKey: [`/api/assessments/${assessmentId}`],
    enabled: !!assessmentId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-bg flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
            <Brain className="text-white h-8 w-8" />
          </div>
          <p className="text-gray-600">Loading your results...</p>
        </div>
      </div>
    );
  }

  if (error || !assessment) {
    return (
      <div className="min-h-screen bg-gradient-bg flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="p-8 text-center">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Results Not Found</h2>
            <p className="text-gray-600 mb-4">We couldn't find your assessment results.</p>
            <Button onClick={() => setLocation("/")}>Return Home</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const personalityInfo = personalityTypes[assessment.personalityType];
  const scores = assessment.scores as any;

  if (!personalityInfo) {
    return (
      <div className="min-h-screen bg-gradient-bg flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="p-8 text-center">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Invalid Personality Type</h2>
            <p className="text-gray-600 mb-4">The personality type could not be determined.</p>
            <Button onClick={() => setLocation("/")}>Return Home</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-bg">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-2xl font-bold text-primary flex items-center">
                  <Brain className="mr-2 h-6 w-6" />
                  MBTI Assessment
                </h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Result Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-32 h-32 bg-gradient-to-r from-primary to-secondary rounded-full mb-6 p-6">
            <PersonalityIcon type={assessment.personalityType} className="w-20 h-20 text-white" />
          </div>
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full mb-4">
            <span className="text-white text-2xl font-bold">{assessment.personalityType}</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            {personalityInfo.title}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {personalityInfo.description}
          </p>
        </div>

        {/* Personality Breakdown */}
        <PersonalityBreakdown 
          personalityType={assessment.personalityType}
          scores={scores}
        />

        {/* Detailed Description */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardContent className="p-8">
                <h3 className="text-2xl font-semibold text-gray-900 mb-6">About Your Personality</h3>
                <div className="space-y-4 text-gray-700">
                  {personalityInfo.details.map((detail, index) => (
                    <p key={index}>{detail}</p>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="space-y-6">
            <Card className="shadow-lg">
              <CardContent className="p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <Heart className="text-red-500 mr-2 h-5 w-5" />
                  Strengths
                </h4>
                <ul className="space-y-2 text-gray-700">
                  {personalityInfo.strengths.map((strength, index) => (
                    <li key={index}>• {strength}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
            
            <Card className="shadow-lg">
              <CardContent className="p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <AlertTriangle className="text-yellow-500 mr-2 h-5 w-5" />
                  Areas for Growth
                </h4>
                <ul className="space-y-2 text-gray-700">
                  {personalityInfo.growthAreas.map((area, index) => (
                    <li key={index}>• {area}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Career Suggestions */}
        <Card className="shadow-lg mb-12">
          <CardContent className="p-8">
            <h3 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
              <Briefcase className="text-primary mr-2 h-6 w-6" />
              Career Suggestions
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {personalityInfo.careers.map((career, index) => (
                <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                  <div className="text-2xl mb-2">{career.icon}</div>
                  <h4 className="font-semibold text-gray-900">{career.category}</h4>
                  <p className="text-sm text-gray-600">{career.examples}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="text-center space-y-4">
          <Button
            onClick={() => setLocation("/assessment")}
            className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 text-white px-8 py-3 font-semibold mr-4"
          >
            <RotateCcw className="mr-2 h-5 w-5" />
            Retake Assessment
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              navigator.share?.({
                title: `My MBTI Result: ${assessment.personalityType}`,
                text: `I just discovered I'm ${personalityInfo.title}! ${personalityInfo.description}`,
                url: window.location.href,
              });
            }}
            className="px-8 py-3 font-semibold"
          >
            <Share2 className="mr-2 h-5 w-5" />
            Share Results
          </Button>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>&copy; 2024 MBTI Assessment. Built for educational purposes.</p>
            <p className="mt-2 text-sm">Based on the Myers-Briggs Type Indicator framework.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Brain, ChevronLeft, ChevronRight, SkipForward } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { QuestionCard } from "@/components/question-card";
import { calculateMBTI } from "@/lib/mbti-calculator";
import { questions } from "@/lib/questions";
import type { QuestionAnswer } from "@shared/schema";

export default function Assessment() {
  const [, setLocation] = useLocation();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<QuestionAnswer[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const totalQuestions = questions.length;
  const progress = ((currentQuestion + 1) / totalQuestions) * 100;

  const saveAssessmentMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/assessments", data);
      return response.json();
    },
    onSuccess: (data) => {
      setLocation(`/results/${data.id}`);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save assessment results. Please try again.",
        variant: "destructive",
      });
      setIsLoading(false);
    },
  });

  const handleAnswer = (questionId: number, answer: 'agree' | 'neutral' | 'disagree') => {
    const newAnswers = [...answers];
    const existingIndex = newAnswers.findIndex(a => a.questionId === questionId);
    
    if (existingIndex >= 0) {
      newAnswers[existingIndex] = { questionId, answer };
    } else {
      newAnswers.push({ questionId, answer });
    }
    
    setAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      completeAssessment();
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSkip = () => {
    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      completeAssessment();
    }
  };

  const completeAssessment = async () => {
    if (answers.length === 0) {
      toast({
        title: "No answers provided",
        description: "Please answer at least one question before completing the assessment.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    const result = calculateMBTI(answers);
    
    const assessmentData = {
      userId: null,
      answers: answers,
      personalityType: result.type,
      scores: result.scores,
    };

    saveAssessmentMutation.mutate(assessmentData);
  };

  const currentAnswer = answers.find(a => a.questionId === questions[currentQuestion].id)?.answer;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-bg flex items-center justify-center">
        <Card className="max-w-2xl mx-4 shadow-lg">
          <CardContent className="p-12 text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
              <Brain className="text-white h-8 w-8" />
            </div>
            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Analyzing Your Responses</h3>
            <p className="text-gray-600 mb-8">We're calculating your personality type based on your answers...</p>
            
            <div className="flex justify-center space-x-2">
              <div className="w-3 h-3 bg-primary rounded-full animate-bounce-dot"></div>
              <div className="w-3 h-3 bg-primary rounded-full animate-bounce-dot"></div>
              <div className="w-3 h-3 bg-primary rounded-full animate-bounce-dot"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-bg">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-2xl font-bold text-primary flex items-center">
                  <Brain className="mr-2 h-6 w-6" />
                  MBTI Assessment
                </h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">
              Question {currentQuestion + 1} of {totalQuestions}
            </span>
            <span className="text-sm font-medium text-gray-700">
              {Math.round(progress)}% Complete
            </span>
          </div>
          <Progress value={progress} className="h-3" />
        </div>

        {/* Question Card */}
        <QuestionCard
          question={questions[currentQuestion]}
          currentAnswer={currentAnswer}
          onAnswer={handleAnswer}
        />

        {/* Navigation Buttons */}
        <div className="flex justify-between items-center mt-8">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="flex items-center"
          >
            <ChevronLeft className="mr-2 h-4 w-4" />
            Previous
          </Button>
          
          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={handleSkip}
              className="flex items-center"
            >
              <SkipForward className="mr-2 h-4 w-4" />
              Skip Question
            </Button>
            <Button
              onClick={handleNext}
              disabled={!currentAnswer && currentQuestion === totalQuestions - 1}
              className="flex items-center bg-primary hover:bg-primary/90"
            >
              {currentQuestion === totalQuestions - 1 ? 'Complete' : 'Next'}
              <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}

import type { QuestionAnswer, MBTIScores } from "@shared/schema";
import { questions } from "./questions";

export function calculateMBTI(answers: QuestionAnswer[]): { type: string; scores: MBTIScores } {
  const scores: MBTIScores = {
    E: 0,
    I: 0,
    S: 0,
    N: 0,
    T: 0,
    F: 0,
    J: 0,
    P: 0,
  };

  // Calculate raw scores based on answers
  answers.forEach(answer => {
    const question = questions.find(q => q.id === answer.questionId);
    if (!question) return;

    const weight = getAnswerWeight(answer.answer);
    
    question.dimensions.forEach(dimension => {
      scores[dimension as keyof MBTIScores] += weight;
    });
  });

  // Convert to percentages (assuming max possible score per dimension)
  const maxScore = questions.filter(q => q.dimensions.includes('E')).length * 2; // 2 points max per question
  
  // Calculate percentages for each dimension pair
  const eTotal = scores.E + scores.I;
  const sTotal = scores.S + scores.N;
  const tTotal = scores.T + scores.F;
  const jTotal = scores.J + scores.P;

  if (eTotal > 0) {
    scores.E = (scores.E / eTotal) * 100;
    scores.I = (scores.I / eTotal) * 100;
  }
  
  if (sTotal > 0) {
    scores.S = (scores.S / sTotal) * 100;
    scores.N = (scores.N / sTotal) * 100;
  }
  
  if (tTotal > 0) {
    scores.T = (scores.T / tTotal) * 100;
    scores.F = (scores.F / tTotal) * 100;
  }
  
  if (jTotal > 0) {
    scores.J = (scores.J / jTotal) * 100;
    scores.P = (scores.P / jTotal) * 100;
  }

  // Determine personality type
  const type = [
    scores.E > scores.I ? 'E' : 'I',
    scores.S > scores.N ? 'S' : 'N',
    scores.T > scores.F ? 'T' : 'F',
    scores.J > scores.P ? 'J' : 'P',
  ].join('');

  return { type, scores };
}

function getAnswerWeight(answer: 'agree' | 'neutral' | 'disagree'): number {
  switch (answer) {
    case 'agree':
      return 2;
    case 'neutral':
      return 1;
    case 'disagree':
      return 0;
    default:
      return 1;
  }
}

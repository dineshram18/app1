export interface PersonalityType {
  title: string;
  description: string;
  details: string[];
  strengths: string[];
  growthAreas: string[];
  careers: {
    category: string;
    examples: string;
    icon: string;
  }[];
}

export const personalityTypes: Record<string, PersonalityType> = {
  INTJ: {
    title: "The Architect",
    description: "Imaginative and strategic thinkers, with a plan for everything.",
    details: [
      "INTJs are known for their ability to see the big picture and develop comprehensive strategies to achieve their goals. They are highly independent and prefer to work alone or in small groups.",
      "These individuals are natural problem-solvers who enjoy complex challenges and intellectual discussions. They value competence and efficiency in themselves and others.",
      "INTJs often have a strong vision for the future and are willing to work tirelessly to bring their ideas to fruition. They prefer structured environments where they can focus on long-term projects."
    ],
    strengths: [
      "Strategic thinking",
      "Independent and self-motivated",
      "High standards and quality focus",
      "Innovative problem-solving",
      "Long-term vision"
    ],
    growthAreas: [
      "Can be overly critical",
      "May struggle with emotional expression",
      "Tendency to be impatient with inefficiency",
      "Can appear aloof or distant",
      "May neglect practical details"
    ],
    careers: [
      { category: "Strategy", examples: "Consultant, Analyst, Researcher", icon: "🎯" },
      { category: "Technology", examples: "Software Engineer, Data Scientist", icon: "💻" },
      { category: "Science", examples: "Scientist, Engineer, Architect", icon: "🔬" }
    ]
  },
  INTP: {
    title: "The Thinker",
    description: "Innovative inventors with an unquenchable thirst for knowledge.",
    details: [
      "INTPs are driven by their curiosity and desire to understand how things work. They are natural theorists who enjoy exploring ideas and concepts for their own sake.",
      "These individuals are highly analytical and logical, preferring to base their decisions on objective analysis rather than emotional considerations. They value intellectual honesty and precision.",
      "INTPs are typically flexible and adaptable, comfortable with ambiguity and change. They prefer to keep their options open and may struggle with rigid deadlines or structures."
    ],
    strengths: [
      "Analytical and logical thinking",
      "Creative problem-solving",
      "Intellectually curious",
      "Flexible and adaptable",
      "Independent thinking"
    ],
    growthAreas: [
      "Can be indecisive",
      "May struggle with routine tasks",
      "Tendency to procrastinate",
      "Can be insensitive to others' feelings",
      "May have difficulty with practical matters"
    ],
    careers: [
      { category: "Research", examples: "Scientist, Academic, Researcher", icon: "🔍" },
      { category: "Technology", examples: "Programmer, Systems Analyst", icon: "💻" },
      { category: "Creative", examples: "Writer, Artist, Designer", icon: "🎨" }
    ]
  },
  ENTJ: {
    title: "The Commander",
    description: "Bold, imaginative and strong-willed leaders, always finding a way—or making one.",
    details: [
      "ENTJs are natural leaders who are driven to organize and direct others toward common goals. They are confident, assertive, and have a strong desire to achieve success.",
      "These individuals are highly strategic and enjoy taking on leadership roles where they can implement their vision. They are excellent at seeing the big picture and developing comprehensive plans.",
      "ENTJs are typically very goal-oriented and results-focused. They have high standards for themselves and others and are not afraid to make tough decisions when necessary."
    ],
    strengths: [
      "Natural leadership abilities",
      "Strategic and visionary thinking",
      "Confident and assertive",
      "Goal-oriented and results-focused",
      "Excellent at organizing and directing"
    ],
    growthAreas: [
      "Can be overly demanding",
      "May struggle with patience",
      "Tendency to be controlling",
      "Can be insensitive to others' feelings",
      "May neglect personal relationships"
    ],
    careers: [
      { category: "Leadership", examples: "CEO, Manager, Director", icon: "👑" },
      { category: "Business", examples: "Entrepreneur, Consultant", icon: "💼" },
      { category: "Law", examples: "Lawyer, Judge, Legal Advisor", icon: "⚖️" }
    ]
  },
  ENTP: {
    title: "The Debater",
    description: "Smart and curious thinkers who cannot resist an intellectual challenge.",
    details: [
      "ENTPs are enthusiastic and creative individuals who love to explore new ideas and possibilities. They are natural innovators who enjoy brainstorming and developing creative solutions.",
      "These individuals are excellent debaters who enjoy intellectual sparring and challenging conventional wisdom. They are quick-witted and articulate, able to see multiple perspectives on any issue.",
      "ENTPs are typically very social and enjoy engaging with others in stimulating conversations. They are energized by new experiences and may become bored with routine or repetitive tasks."
    ],
    strengths: [
      "Innovative and creative thinking",
      "Excellent communication skills",
      "Enthusiastic and energetic",
      "Quick-witted and articulate",
      "Adaptable and flexible"
    ],
    growthAreas: [
      "Can be argumentative",
      "May struggle with follow-through",
      "Tendency to be scattered",
      "Can be insensitive to others' feelings",
      "May neglect practical details"
    ],
    careers: [
      { category: "Innovation", examples: "Entrepreneur, Inventor, Consultant", icon: "💡" },
      { category: "Communication", examples: "Journalist, Public Speaker", icon: "📢" },
      { category: "Creative", examples: "Marketing, Advertising, Design", icon: "🎨" }
    ]
  },
  INFJ: {
    title: "The Advocate",
    description: "Quiet and mystical, yet very inspiring and tireless idealists.",
    details: [
      "INFJs are deeply empathetic individuals who are driven by their values and desire to help others. They have a strong sense of purpose and are committed to making a positive difference in the world.",
      "These individuals are highly intuitive and often have insights into people and situations that others miss. They are excellent listeners and are skilled at understanding and supporting others.",
      "INFJs are typically very private and selective about who they let into their inner circle. They need time alone to recharge and process their thoughts and feelings."
    ],
    strengths: [
      "Empathetic and compassionate",
      "Insightful and intuitive",
      "Creative and imaginative",
      "Committed to their values",
      "Excellent at understanding others"
    ],
    growthAreas: [
      "Can be overly sensitive",
      "May struggle with criticism",
      "Tendency to be perfectionistic",
      "Can be overly idealistic",
      "May neglect their own needs"
    ],
    careers: [
      { category: "Helping", examples: "Counselor, Therapist, Social Worker", icon: "🤝" },
      { category: "Creative", examples: "Writer, Artist, Designer", icon: "🎨" },
      { category: "Education", examples: "Teacher, Trainer, Coach", icon: "📚" }
    ]
  },
  INFP: {
    title: "The Mediator",
    description: "Poetic, kind and altruistic people, always eager to help a good cause.",
    details: [
      "INFPs are idealistic and values-driven individuals who are passionate about causes they believe in. They have a strong desire to help others and make the world a better place.",
      "These individuals are highly creative and imaginative, often expressing themselves through art, writing, or other creative outlets. They are deeply empathetic and skilled at understanding others' emotions.",
      "INFPs are typically very flexible and adaptable, preferring to keep their options open rather than making firm commitments. They value authenticity and are true to their own beliefs and values."
    ],
    strengths: [
      "Idealistic and values-driven",
      "Creative and imaginative",
      "Empathetic and compassionate",
      "Flexible and adaptable",
      "Authentic and genuine"
    ],
    growthAreas: [
      "Can be overly sensitive",
      "May struggle with criticism",
      "Tendency to be disorganized",
      "Can be overly idealistic",
      "May have difficulty with conflict"
    ],
    careers: [
      { category: "Creative", examples: "Writer, Artist, Musician", icon: "🎨" },
      { category: "Helping", examples: "Counselor, Social Worker, Therapist", icon: "🤝" },
      { category: "Education", examples: "Teacher, Trainer, Coach", icon: "📚" }
    ]
  },
  ENFJ: {
    title: "The Protagonist",
    description: "Charismatic and inspiring leaders, able to mesmerize their listeners.",
    details: [
      "ENFJs are natural leaders who are driven by their desire to help others reach their potential. They are charismatic and inspiring, able to motivate and guide others toward positive change.",
      "These individuals are highly empathetic and skilled at understanding and responding to others' needs. They are excellent communicators and are able to connect with people on a deep level.",
      "ENFJs are typically very organized and goal-oriented, able to develop and implement plans to achieve their vision. They are committed to their values and are willing to work hard to make a positive difference."
    ],
    strengths: [
      "Charismatic and inspiring",
      "Empathetic and understanding",
      "Excellent communication skills",
      "Organized and goal-oriented",
      "Committed to helping others"
    ],
    growthAreas: [
      "Can be overly helpful",
      "May struggle with saying no",
      "Tendency to be overly sensitive",
      "Can be overly idealistic",
      "May neglect their own needs"
    ],
    careers: [
      { category: "Leadership", examples: "Manager, Director, Team Leader", icon: "👑" },
      { category: "Education", examples: "Teacher, Trainer, Coach", icon: "📚" },
      { category: "Helping", examples: "Counselor, Social Worker, HR", icon: "🤝" }
    ]
  },
  ENFP: {
    title: "The Campaigner",
    description: "Enthusiastic, creative and sociable free spirits, who can always find a reason to smile.",
    details: [
      "ENFPs are people-centered creators with a focus on possibilities and a contagious enthusiasm for new ideas, people and activities. They are energetic, warm, and passionate. ENFPs love to help other people explore their creative potential.",
      "ENFPs are typically agile and expressive communicators, using their wit, humor, and mastery of language to create engaging stories. Their intuitive nature allows them to see connections and patterns that others might miss.",
      "In relationships, ENFPs are warm and encouraging. They are skilled at understanding their partner's needs and are energetic in providing support. However, they may struggle with routine tasks and prefer flexibility over rigid structure."
    ],
    strengths: [
      "Enthusiastic and energetic",
      "Creative and imaginative",
      "Empathetic and caring",
      "Excellent communication skills",
      "Adaptable and flexible"
    ],
    growthAreas: [
      "Can be overly optimistic",
      "May struggle with routine tasks",
      "Tendency to overthink",
      "Difficulty with criticism",
      "May neglect practical matters"
    ],
    careers: [
      { category: "Creative", examples: "Writer, Designer, Artist", icon: "🎨" },
      { category: "People-Oriented", examples: "Counselor, Teacher, HR", icon: "🤝" },
      { category: "Innovation", examples: "Entrepreneur, Consultant", icon: "💡" }
    ]
  },
  ISTJ: {
    title: "The Logistician",
    description: "Practical and fact-minded, reliable and responsible.",
    details: [
      "ISTJs are responsible and hardworking individuals who value tradition and stability. They are practical and logical, preferring to base their decisions on facts and proven methods.",
      "These individuals are highly organized and systematic, excellent at managing details and following through on commitments. They have a strong sense of duty and are reliable team members.",
      "ISTJs prefer structured environments where they can work methodically toward clear goals. They are patient and persistent, willing to work steadily toward long-term objectives."
    ],
    strengths: [
      "Reliable and responsible",
      "Practical and logical",
      "Excellent at managing details",
      "Strong sense of duty",
      "Patient and persistent"
    ],
    growthAreas: [
      "Can be rigid and inflexible",
      "May struggle with change",
      "Tendency to be overly cautious",
      "Can be critical of others",
      "May neglect creative possibilities"
    ],
    careers: [
      { category: "Administration", examples: "Manager, Administrator, Analyst", icon: "📊" },
      { category: "Finance", examples: "Accountant, Auditor, Financial Planner", icon: "💰" },
      { category: "Healthcare", examples: "Doctor, Nurse, Pharmacist", icon: "🏥" }
    ]
  },
  ISFJ: {
    title: "The Protector",
    description: "Warm-hearted and dedicated, always ready to protect their loved ones.",
    details: [
      "ISFJs are caring and conscientious individuals who are driven by their desire to help and protect others. They are warm, supportive, and deeply committed to their relationships.",
      "These individuals are highly observant and skilled at understanding others' needs. They are excellent at providing practical support and creating harmonious environments.",
      "ISFJs are typically very reliable and hardworking, willing to go above and beyond to help others. They prefer stable, structured environments where they can focus on serving others."
    ],
    strengths: [
      "Caring and compassionate",
      "Reliable and hardworking",
      "Excellent at supporting others",
      "Observant and detail-oriented",
      "Creates harmony and stability"
    ],
    growthAreas: [
      "Can be overly selfless",
      "May struggle with conflict",
      "Tendency to be overly sensitive",
      "Can be resistant to change",
      "May neglect their own needs"
    ],
    careers: [
      { category: "Healthcare", examples: "Nurse, Doctor, Therapist", icon: "🏥" },
      { category: "Education", examples: "Teacher, Counselor, Librarian", icon: "📚" },
      { category: "Service", examples: "Social Worker, HR, Customer Service", icon: "🤝" }
    ]
  },
  ESTJ: {
    title: "The Executive",
    description: "Excellent administrators, unsurpassed at managing things—or people.",
    details: [
      "ESTJs are natural organizers who excel at managing people and resources to achieve goals. They are practical, efficient, and results-oriented, with a strong focus on getting things done.",
      "These individuals are confident leaders who are skilled at making decisions and implementing plans. They value tradition and established procedures, preferring proven methods over untested approaches.",
      "ESTJs are typically very goal-oriented and competitive, driven to achieve success in their chosen endeavors. They are excellent at motivating others and creating productive work environments."
    ],
    strengths: [
      "Excellent leadership skills",
      "Practical and efficient",
      "Results-oriented and goal-focused",
      "Good at organizing and managing",
      "Confident decision-makers"
    ],
    growthAreas: [
      "Can be overly controlling",
      "May struggle with flexibility",
      "Tendency to be impatient",
      "Can be insensitive to others' feelings",
      "May neglect creative possibilities"
    ],
    careers: [
      { category: "Management", examples: "Manager, Director, Executive", icon: "👑" },
      { category: "Business", examples: "Sales Manager, Project Manager", icon: "💼" },
      { category: "Government", examples: "Administrator, Military Officer", icon: "🏛️" }
    ]
  },
  ESFJ: {
    title: "The Consul",
    description: "Extraordinarily caring, social and popular people, always eager to help.",
    details: [
      "ESFJs are warm, caring individuals who are deeply committed to helping others and creating harmony in their relationships. They are highly social and enjoy being around people.",
      "These individuals are skilled at understanding and responding to others' emotional needs. They are excellent at creating supportive environments and building strong relationships.",
      "ESFJs are typically very organized and responsible, excellent at managing details and ensuring that things run smoothly. They prefer structured environments where they can focus on helping others."
    ],
    strengths: [
      "Warm and caring",
      "Excellent at building relationships",
      "Skilled at understanding others' needs",
      "Organized and responsible",
      "Creates harmony and support"
    ],
    growthAreas: [
      "Can be overly people-pleasing",
      "May struggle with conflict",
      "Tendency to be overly sensitive",
      "Can be resistant to change",
      "May neglect their own needs"
    ],
    careers: [
      { category: "Healthcare", examples: "Nurse, Doctor, Therapist", icon: "🏥" },
      { category: "Education", examples: "Teacher, Counselor, Administrator", icon: "📚" },
      { category: "Service", examples: "Social Worker, HR, Customer Service", icon: "🤝" }
    ]
  },
  ISTP: {
    title: "The Virtuoso",
    description: "Bold and practical experimenters, masters of all kinds of tools.",
    details: [
      "ISTPs are practical problem-solvers who enjoy working with their hands and understanding how things work. They are independent and adaptable, preferring to learn through experience.",
      "These individuals are skilled at troubleshooting and fixing problems, often able to quickly identify solutions that others miss. They are logical and analytical, preferring to base their decisions on objective facts.",
      "ISTPs are typically very flexible and spontaneous, comfortable with change and uncertainty. They prefer to keep their options open and may struggle with rigid schedules or long-term commitments."
    ],
    strengths: [
      "Practical problem-solving skills",
      "Independent and self-reliant",
      "Skilled at working with tools",
      "Logical and analytical",
      "Flexible and adaptable"
    ],
    growthAreas: [
      "Can be overly private",
      "May struggle with emotional expression",
      "Tendency to be impulsive",
      "Can be insensitive to others' feelings",
      "May have difficulty with long-term planning"
    ],
    careers: [
      { category: "Technical", examples: "Engineer, Mechanic, Technician", icon: "🔧" },
      { category: "Emergency", examples: "Paramedic, Firefighter, Police", icon: "🚨" },
      { category: "Skilled Trades", examples: "Carpenter, Electrician, Plumber", icon: "🔨" }
    ]
  },
  ISFP: {
    title: "The Adventurer",
    description: "Flexible and charming artists, always ready to explore new possibilities.",
    details: [
      "ISFPs are gentle, caring individuals who are driven by their personal values and desire to help others. They are highly creative and artistic, often expressing themselves through various forms of art.",
      "These individuals are very sensitive to others' emotions and are skilled at providing support and encouragement. They are excellent listeners and are deeply empathetic.",
      "ISFPs are typically very flexible and adaptable, preferring to keep their options open rather than making firm commitments. They value authenticity and are true to their own beliefs and values."
    ],
    strengths: [
      "Creative and artistic",
      "Gentle and caring",
      "Sensitive to others' emotions",
      "Flexible and adaptable",
      "Authentic and genuine"
    ],
    growthAreas: [
      "Can be overly sensitive",
      "May struggle with criticism",
      "Tendency to avoid conflict",
      "Can be disorganized",
      "May have difficulty with decision-making"
    ],
    careers: [
      { category: "Creative", examples: "Artist, Designer, Musician", icon: "🎨" },
      { category: "Helping", examples: "Counselor, Social Worker, Therapist", icon: "🤝" },
      { category: "Nature", examples: "Veterinarian, Park Ranger, Biologist", icon: "🌿" }
    ]
  },
  ESTP: {
    title: "The Entrepreneur",
    description: "Smart, energetic and very perceptive people, who truly enjoy living on the edge.",
    details: [
      "ESTPs are energetic, spontaneous individuals who love to live in the moment and experience new adventures. They are practical and realistic, preferring to learn through hands-on experience.",
      "These individuals are highly social and enjoy being around people. They are skilled at reading social situations and are excellent at adapting to different environments and circumstances.",
      "ESTPs are typically very action-oriented and results-focused, preferring to jump into situations rather than spending time planning. They are excellent at improvising and finding creative solutions under pressure."
    ],
    strengths: [
      "Energetic and spontaneous",
      "Practical and realistic",
      "Highly social and adaptable",
      "Action-oriented and results-focused",
      "Excellent at improvising"
    ],
    growthAreas: [
      "Can be impulsive",
      "May struggle with long-term planning",
      "Tendency to be impatient",
      "Can be insensitive to others' feelings",
      "May have difficulty with routine tasks"
    ],
    careers: [
      { category: "Sales", examples: "Sales Representative, Real Estate Agent", icon: "💼" },
      { category: "Entertainment", examples: "Actor, Performer, Athletic Coach", icon: "🎭" },
      { category: "Emergency", examples: "Paramedic, Firefighter, Police Officer", icon: "🚨" }
    ]
  },
  ESFP: {
    title: "The Entertainer",
    description: "Spontaneous, energetic and enthusiastic people – life is never boring around them.",
    details: [
      "ESFPs are warm, enthusiastic individuals who love to entertain and bring joy to others. They are highly social and enjoy being the center of attention, often using humor and creativity to engage with others.",
      "These individuals are very people-oriented and skilled at understanding and responding to others' emotions. They are excellent at creating fun, engaging experiences and making others feel comfortable.",
      "ESFPs are typically very spontaneous and flexible, preferring to keep their options open and go with the flow. They are optimistic and positive, always looking for the bright side of situations."
    ],
    strengths: [
      "Warm and enthusiastic",
      "Excellent at entertaining others",
      "Highly social and people-oriented",
      "Spontaneous and flexible",
      "Optimistic and positive"
    ],
    growthAreas: [
      "Can be overly emotional",
      "May struggle with criticism",
      "Tendency to avoid conflict",
      "Can be disorganized",
      "May have difficulty with long-term planning"
    ],
    careers: [
      { category: "Entertainment", examples: "Actor, Performer, Event Planner", icon: "🎭" },
      { category: "Service", examples: "Flight Attendant, Tour Guide, Retail", icon: "🛍️" },
      { category: "Education", examples: "Teacher, Trainer, Child Care", icon: "📚" }
    ]
  }
};

export interface Question {
  id: number;
  text: string;
  dimensions: string[];
}

export const questions: Question[] = [
  {
    id: 1,
    text: "You're really quite talkative at social events.",
    dimensions: ['E']
  },
  {
    id: 2,
    text: "You often get so lost in thoughts that you ignore or forget your surroundings.",
    dimensions: ['I']
  },
  {
    id: 3,
    text: "You try to respond to your e-mails as soon as possible and cannot bear a messy inbox.",
    dimensions: ['J']
  },
  {
    id: 4,
    text: "You find it easy to introduce yourself to other people.",
    dimensions: ['E']
  },
  {
    id: 5,
    text: "You often feel as if you have to justify yourself to other people.",
    dimensions: ['I']
  },
  {
    id: 6,
    text: "You consider yourself more practical than creative.",
    dimensions: ['S']
  },
  {
    id: 7,
    text: "You rarely get carried away by fantasies and ideas.",
    dimensions: ['S']
  },
  {
    id: 8,
    text: "You think that everyone's views should be respected regardless of whether they are supported by facts or not.",
    dimensions: ['F']
  },
  {
    id: 9,
    text: "You feel more energetic after spending time with a group of people.",
    dimensions: ['E']
  },
  {
    id: 10,
    text: "You enjoy having a wide circle of acquaintances.",
    dimensions: ['E']
  },
  {
    id: 11,
    text: "You see yourself as very emotionally stable.",
    dimensions: ['T']
  },
  {
    id: 12,
    text: "You are usually highly motivated and energetic.",
    dimensions: ['E']
  },
  {
    id: 13,
    text: "Winning a debate matters less to you than making sure no one gets upset.",
    dimensions: ['F']
  },
  {
    id: 14,
    text: "You prefer to completely finish one project before starting another.",
    dimensions: ['J']
  },
  {
    id: 15,
    text: "You are very sentimental.",
    dimensions: ['F']
  },
  {
    id: 16,
    text: "You find it difficult to introduce yourself to other people.",
    dimensions: ['I']
  },
  {
    id: 17,
    text: "You usually place yourself nearer to the center than the sides at a party.",
    dimensions: ['I']
  },
  {
    id: 18,
    text: "You are more inclined to follow your head than your heart.",
    dimensions: ['T']
  },
  {
    id: 19,
    text: "You are usually the first to react to a sudden event.",
    dimensions: ['E']
  },
  {
    id: 20,
    text: "You are more interested in a general idea than in the details of its realization.",
    dimensions: ['N']
  }
];

import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import type { Question } from "@/lib/questions";

interface QuestionCardProps {
  question: Question;
  currentAnswer?: 'agree' | 'neutral' | 'disagree';
  onAnswer: (questionId: number, answer: 'agree' | 'neutral' | 'disagree') => void;
}

export function QuestionCard({ question, currentAnswer, onAnswer }: QuestionCardProps) {
  const handleValueChange = (value: string) => {
    onAnswer(question.id, value as 'agree' | 'neutral' | 'disagree');
  };

  return (
    <Card className="shadow-lg">
      <CardContent className="p-8">
        <div className="mb-6">
          <h3 className="text-2xl font-semibold text-gray-900 mb-4">
            {question.text}
          </h3>
          <p className="text-gray-600">Choose the option that best describes you:</p>
        </div>

        <RadioGroup value={currentAnswer} onValueChange={handleValueChange}>
          <div className="space-y-4">
            <div className="flex items-center space-x-4 p-4 border-2 border-gray-200 rounded-lg hover:border-primary hover:bg-indigo-50 transition-colors">
              <RadioGroupItem value="agree" id="agree" />
              <Label htmlFor="agree" className="flex-1 cursor-pointer">
                <div>
                  <span className="text-lg font-medium text-gray-900">Agree</span>
                  <p className="text-gray-600">Yes, this describes me well</p>
                </div>
              </Label>
            </div>

            <div className="flex items-center space-x-4 p-4 border-2 border-gray-200 rounded-lg hover:border-primary hover:bg-indigo-50 transition-colors">
              <RadioGroupItem value="neutral" id="neutral" />
              <Label htmlFor="neutral" className="flex-1 cursor-pointer">
                <div>
                  <span className="text-lg font-medium text-gray-900">Neutral</span>
                  <p className="text-gray-600">It depends on the situation</p>
                </div>
              </Label>
            </div>

            <div className="flex items-center space-x-4 p-4 border-2 border-gray-200 rounded-lg hover:border-primary hover:bg-indigo-50 transition-colors">
              <RadioGroupItem value="disagree" id="disagree" />
              <Label htmlFor="disagree" className="flex-1 cursor-pointer">
                <div>
                  <span className="text-lg font-medium text-gray-900">Disagree</span>
                  <p className="text-gray-600">No, this doesn't describe me</p>
                </div>
              </Label>
            </div>
          </div>
        </RadioGroup>
      </CardContent>
    </Card>
  );
}

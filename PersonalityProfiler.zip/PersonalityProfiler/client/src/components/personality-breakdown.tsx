import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import type { MBTIScores } from "@shared/schema";

interface PersonalityBreakdownProps {
  personalityType: string;
  scores: MBTIScores;
}

export function PersonalityBreakdown({ personalityType, scores }: PersonalityBreakdownProps) {
  const dimensions = [
    {
      letter: personalityType[0],
      name: personalityType[0] === 'E' ? 'Extraversion' : 'Introversion',
      percentage: personalityType[0] === 'E' ? scores.E : scores.I,
      color: 'bg-primary',
    },
    {
      letter: personalityType[1],
      name: personalityType[1] === 'S' ? 'Sensing' : 'Intuition',
      percentage: personalityType[1] === 'S' ? scores.S : scores.N,
      color: 'bg-secondary',
    },
    {
      letter: personalityType[2],
      name: personalityType[2] === 'T' ? 'Thinking' : 'Feeling',
      percentage: personalityType[2] === 'T' ? scores.T : scores.F,
      color: 'bg-accent',
    },
    {
      letter: personalityType[3],
      name: personalityType[3] === 'J' ? 'Judging' : 'Perceiving',
      percentage: personalityType[3] === 'J' ? scores.J : scores.P,
      color: 'bg-green-500',
    },
  ];

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
      {dimensions.map((dimension, index) => (
        <Card key={index} className="shadow-lg text-center">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-primary mb-2">{dimension.letter}</div>
            <div className="text-sm text-gray-600 mb-4">{dimension.name}</div>
            <div className="mb-2">
              <Progress value={dimension.percentage} className="h-2" />
            </div>
            <div className="text-sm text-gray-600">{Math.round(dimension.percentage)}%</div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

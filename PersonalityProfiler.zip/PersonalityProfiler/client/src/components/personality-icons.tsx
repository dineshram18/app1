interface PersonalityIconProps {
  type: string;
  className?: string;
}

export function PersonalityIcon({ type, className = "w-16 h-16" }: PersonalityIconProps) {
  const icons: Record<string, JSX.Element> = {
    INTJ: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 30 L50 50 L70 30" fill="none" stroke="currentColor" strokeWidth="3"/>
        <circle cx="50" cy="65" r="8" fill="currentColor"/>
        <path d="M42 75 L58 75" stroke="currentColor" strokeWidth="3"/>
      </svg>
    ),
    INTP: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <circle cx="35" cy="40" r="6" fill="currentColor"/>
        <circle cx="65" cy="40" r="6" fill="currentColor"/>
        <path d="M35 60 Q50 70 65 60" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M40 25 L60 25" stroke="currentColor" strokeWidth="3"/>
      </svg>
    ),
    ENTJ: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 35 L50 20 L70 35" fill="currentColor"/>
        <rect x="45" y="35" width="10" height="30" fill="currentColor"/>
        <path d="M30 65 L70 65" stroke="currentColor" strokeWidth="3"/>
      </svg>
    ),
    ENTP: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M20 50 L35 35 L50 50 L65 35 L80 50" fill="none" stroke="currentColor" strokeWidth="3"/>
        <circle cx="50" cy="65" r="5" fill="currentColor"/>
        <path d="M25 65 L75 65" stroke="currentColor" strokeWidth="2"/>
      </svg>
    ),
    INFJ: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M50 25 L50 75" stroke="currentColor" strokeWidth="3"/>
        <circle cx="50" cy="35" r="8" fill="currentColor"/>
        <path d="M35 55 Q50 65 65 55" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M40 70 L60 70" stroke="currentColor" strokeWidth="2"/>
      </svg>
    ),
    INFP: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 40 Q50 20 70 40" fill="none" stroke="currentColor" strokeWidth="3"/>
        <circle cx="40" cy="55" r="5" fill="currentColor"/>
        <circle cx="60" cy="55" r="5" fill="currentColor"/>
        <path d="M35 70 Q50 80 65 70" fill="none" stroke="currentColor" strokeWidth="3"/>
      </svg>
    ),
    ENFJ: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M50 25 L50 75" stroke="currentColor" strokeWidth="3"/>
        <circle cx="50" cy="40" r="10" fill="currentColor"/>
        <path d="M25 60 L75 60" stroke="currentColor" strokeWidth="3"/>
        <path d="M35 75 L65 75" stroke="currentColor" strokeWidth="3"/>
      </svg>
    ),
    ENFP: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 30 Q50 10 70 30" fill="none" stroke="currentColor" strokeWidth="3"/>
        <circle cx="35" cy="50" r="6" fill="currentColor"/>
        <circle cx="65" cy="50" r="6" fill="currentColor"/>
        <path d="M30 70 Q50 80 70 70" fill="none" stroke="currentColor" strokeWidth="3"/>
      </svg>
    ),
    ISTJ: (
      <svg viewBox="0 0 100 100" className={className}>
        <rect x="15" y="15" width="70" height="70" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 30 L70 30" stroke="currentColor" strokeWidth="2"/>
        <path d="M30 45 L70 45" stroke="currentColor" strokeWidth="2"/>
        <path d="M30 60 L70 60" stroke="currentColor" strokeWidth="2"/>
        <path d="M30 75 L70 75" stroke="currentColor" strokeWidth="2"/>
        <circle cx="22" cy="30" r="3" fill="currentColor"/>
        <circle cx="22" cy="45" r="3" fill="currentColor"/>
        <circle cx="22" cy="60" r="3" fill="currentColor"/>
        <circle cx="22" cy="75" r="3" fill="currentColor"/>
      </svg>
    ),
    ISFJ: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M50 25 L50 75" stroke="currentColor" strokeWidth="3"/>
        <path d="M25 50 L75 50" stroke="currentColor" strokeWidth="3"/>
        <circle cx="50" cy="35" r="6" fill="currentColor"/>
        <circle cx="35" cy="50" r="6" fill="currentColor"/>
        <circle cx="65" cy="50" r="6" fill="currentColor"/>
        <circle cx="50" cy="65" r="6" fill="currentColor"/>
      </svg>
    ),
    ESTJ: (
      <svg viewBox="0 0 100 100" className={className}>
        <rect x="15" y="15" width="70" height="70" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 30 L70 30" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 50 L70 50" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 70 L70 70" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 15 L30 85" stroke="currentColor" strokeWidth="3"/>
        <path d="M50 15 L50 85" stroke="currentColor" strokeWidth="3"/>
        <path d="M70 15 L70 85" stroke="currentColor" strokeWidth="3"/>
      </svg>
    ),
    ESFJ: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 35 Q50 25 70 35" fill="none" stroke="currentColor" strokeWidth="3"/>
        <circle cx="35" cy="45" r="5" fill="currentColor"/>
        <circle cx="65" cy="45" r="5" fill="currentColor"/>
        <path d="M30 60 Q50 70 70 60" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M40 75 L60 75" stroke="currentColor" strokeWidth="3"/>
      </svg>
    ),
    ISTP: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 30 L70 70" stroke="currentColor" strokeWidth="3"/>
        <path d="M70 30 L30 70" stroke="currentColor" strokeWidth="3"/>
        <circle cx="50" cy="50" r="8" fill="currentColor"/>
        <circle cx="30" cy="30" r="4" fill="currentColor"/>
        <circle cx="70" cy="30" r="4" fill="currentColor"/>
        <circle cx="30" cy="70" r="4" fill="currentColor"/>
        <circle cx="70" cy="70" r="4" fill="currentColor"/>
      </svg>
    ),
    ISFP: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 40 Q50 25 70 40" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M30 60 Q50 75 70 60" fill="none" stroke="currentColor" strokeWidth="3"/>
        <circle cx="50" cy="50" r="6" fill="currentColor"/>
        <circle cx="35" cy="35" r="3" fill="currentColor"/>
        <circle cx="65" cy="35" r="3" fill="currentColor"/>
        <circle cx="35" cy="65" r="3" fill="currentColor"/>
        <circle cx="65" cy="65" r="3" fill="currentColor"/>
      </svg>
    ),
    ESTP: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M25 40 L75 40" stroke="currentColor" strokeWidth="3"/>
        <path d="M25 60 L75 60" stroke="currentColor" strokeWidth="3"/>
        <circle cx="40" cy="25" r="6" fill="currentColor"/>
        <circle cx="60" cy="25" r="6" fill="currentColor"/>
        <circle cx="40" cy="75" r="6" fill="currentColor"/>
        <circle cx="60" cy="75" r="6" fill="currentColor"/>
      </svg>
    ),
    ESFP: (
      <svg viewBox="0 0 100 100" className={className}>
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M20 30 Q50 10 80 30" fill="none" stroke="currentColor" strokeWidth="3"/>
        <path d="M20 70 Q50 90 80 70" fill="none" stroke="currentColor" strokeWidth="3"/>
        <circle cx="35" cy="50" r="7" fill="currentColor"/>
        <circle cx="65" cy="50" r="7" fill="currentColor"/>
        <path d="M35 40 Q50 35 65 40" fill="none" stroke="currentColor" strokeWidth="2"/>
        <path d="M35 60 Q50 65 65 60" fill="none" stroke="currentColor" strokeWidth="2"/>
      </svg>
    ),
  };

  return icons[type] || icons.INTJ;
}